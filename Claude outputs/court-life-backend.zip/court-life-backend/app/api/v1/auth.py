import uuid
from datetime import UTC, datetime, timedelta

import jwt
from fastapi import APIRouter, HTTPException, Request, status
from sqlalchemy import select, update

from app.api.deps import DB, CurrentUser, audit
from app.core.config import settings
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    generate_otp,
    hash_otp,
    hash_password,
    verify_password,
)
from app.i18n import t
from app.models import OtpCode, User
from app.providers.messaging import ChannelError, get_sms
from app.schemas import (
    ChangePasswordIn,
    LoginIn,
    OtpRequestIn,
    OtpVerifyIn,
    PreferencesUpdate,
    RefreshIn,
    TokenOut,
    UserOut,
)
from app.services.usage import record_usage

router = APIRouter(prefix="/auth", tags=["auth"])


def _tokens(user: User) -> TokenOut:
    return TokenOut(
        access_token=create_access_token(user.id, user.role, user.tenant_id),
        refresh_token=create_refresh_token(user.id),
        user=UserOut.model_validate(user),
    )


def _check_login_allowed(user: User | None) -> User:
    if user is None or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")
    if user.tenant is not None and user.tenant.status != "active":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Law firm account is suspended")
    return user


@router.post("/login", response_model=TokenOut)
async def login(body: LoginIn, db: DB, request: Request):
    user = (await db.execute(select(User).where(User.email == body.email.lower()))).scalar_one_or_none()
    if user is None or not verify_password(body.password, user.hashed_password):
        await audit(
            db, None, "auth.login_failed", "user", None, {"email": body.email.lower()}, request, tenant_id=user.tenant_id if user else None
        )
        await db.commit()
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")
    _check_login_allowed(user)
    user.last_login_at = datetime.now(UTC)
    await audit(db, user, "auth.login", "user", user.id, request=request)
    return _tokens(user)


@router.post("/otp/request", status_code=202)
async def otp_request(body: OtpRequestIn, db: DB):
    """Phone OTP login (mainly for clients). Always 202 so phone numbers can't be enumerated."""
    user = (await db.execute(select(User).where(User.phone == body.phone, User.is_active.is_(True)))).scalars().first()
    if user is None:
        return {"detail": "If the number is registered, a code has been sent."}
    recent = (
        await db.execute(select(OtpCode).where(OtpCode.phone == body.phone, OtpCode.created_at > datetime.now(UTC) - timedelta(seconds=30)))
    ).first()
    if recent:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Please wait before requesting another code")
    await db.execute(update(OtpCode).where(OtpCode.phone == body.phone, OtpCode.used.is_(False)).values(used=True))
    code = generate_otp()
    db.add(OtpCode(phone=body.phone, code_hash=hash_otp(code), expires_at=datetime.now(UTC) + timedelta(minutes=settings.OTP_TTL_MINUTES)))
    try:
        await get_sms().send(body.phone, t("otp.sms", user.language, code=code, minutes=settings.OTP_TTL_MINUTES))
        record_usage(db, user.tenant_id, get_sms().name, "sms")
    except ChannelError:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, "Could not send OTP") from None
    return {"detail": "If the number is registered, a code has been sent."}


@router.post("/otp/verify", response_model=TokenOut)
async def otp_verify(body: OtpVerifyIn, db: DB, request: Request):
    otp = (
        await db.execute(
            select(OtpCode).where(OtpCode.phone == body.phone, OtpCode.used.is_(False)).order_by(OtpCode.created_at.desc()).limit(1)
        )
    ).scalar_one_or_none()
    if otp is None or otp.expires_at < datetime.now(UTC) or otp.attempts >= settings.OTP_MAX_ATTEMPTS:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Code expired or invalid")
    if otp.code_hash != hash_otp(body.code):
        otp.attempts += 1
        await db.commit()
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Code expired or invalid")
    otp.used = True
    user = (await db.execute(select(User).where(User.phone == body.phone, User.is_active.is_(True)))).scalars().first()
    _check_login_allowed(user)
    user.last_login_at = datetime.now(UTC)
    await audit(db, user, "auth.login_otp", "user", user.id, request=request)
    return _tokens(user)


@router.post("/refresh", response_model=TokenOut)
async def refresh(body: RefreshIn, db: DB):
    try:
        payload = decode_token(body.refresh_token, "refresh")
        user = await db.get(User, uuid.UUID(payload["sub"]))
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid refresh token") from None
    return _tokens(_check_login_allowed(user))


@router.get("/me", response_model=UserOut)
async def me(user: CurrentUser):
    return user


@router.patch("/me", response_model=UserOut)
async def update_me(body: PreferencesUpdate, user: CurrentUser, db: DB):
    data = body.model_dump(exclude_unset=True)
    now = datetime.now(UTC)
    if "sms_consent" in data:
        user.sms_consent_at = now if data.pop("sms_consent") else None
    if "call_consent" in data:
        user.call_consent_at = now if data.pop("call_consent") else None
    for k, v in data.items():
        setattr(user, k, v)
    await audit(db, user, "user.preferences_updated", "user", user.id, {"fields": sorted(body.model_dump(exclude_unset=True))})
    await db.flush()
    return user


@router.post("/change-password", status_code=204)
async def change_password(body: ChangePasswordIn, user: CurrentUser, db: DB):
    if not verify_password(body.current_password, user.hashed_password):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Current password is incorrect")
    user.hashed_password = hash_password(body.new_password)
    await audit(db, user, "auth.password_changed", "user", user.id)
