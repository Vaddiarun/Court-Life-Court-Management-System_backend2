"""Metadata, provider webhooks and operator job triggers."""

import hmac

from fastapi import APIRouter, Form, HTTPException, Query
from pydantic import BaseModel

from app.api.deps import DB, SuperAdmin
from app.core.config import settings
from app.i18n import LANGUAGES, translations_available
from app.models.enums import Channel, DocumentCategory, ReminderType, Role
from app.providers.court.base import is_valid_cnr, normalize_cnr
from app.services.reminders import dispatch_due, handle_call_status
from app.services.sync import collect_refreshed, mark_cnr_changed, request_refreshes

router = APIRouter(tags=["system"])


def _check_token(token: str | None) -> None:
    if not token or not hmac.compare_digest(token, settings.WEBHOOK_SECRET):
        raise HTTPException(401, "Invalid webhook token")


@router.get("/meta/languages")
async def languages():
    have = translations_available()
    return [{**lang, "notification_templates": lang["code"] in have} for lang in LANGUAGES]


@router.get("/meta/enums")
async def enums():
    return {
        "roles": [r.value for r in Role],
        "reminder_types": [r.value for r in ReminderType],
        "channels": [c.value for c in Channel],
        "document_categories": [c.value for c in DocumentCategory],
        "default_reminder_offsets_days": [7, 3, 1, 0],
    }


@router.post("/webhooks/exotel/call-status")
async def exotel_call_status(
    db: DB,
    token: str = Query(...),
    CallSid: str = Form(...),
    Status: str = Form(...),
    ConversationDuration: int | None = Form(None),
):
    _check_token(token)
    found = await handle_call_status(db, CallSid, Status, ConversationDuration)
    return {"ok": True, "matched": found}


class CourtWebhookIn(BaseModel):
    cnr: str


@router.post("/webhooks/court-provider")
async def court_provider_webhook(body: CourtWebhookIn, db: DB, token: str = Query(...)):
    """Portfolio-monitoring callback: the provider tells us a CNR changed."""
    _check_token(token)
    cnr = normalize_cnr(body.cnr)
    if not is_valid_cnr(cnr):
        raise HTTPException(422, "Invalid CNR")
    return {"ok": True, "cases_marked": await mark_cnr_changed(db, cnr)}


@router.post("/admin/jobs/sync")
async def run_sync_now(admin: SuperAdmin, db: DB):
    """Operator trigger for the scheduled sync (normally run by Celery beat)."""
    requested = await request_refreshes(db)
    collected = await collect_refreshed(db)
    return {"refresh_requested": requested, **collected}


@router.post("/admin/jobs/dispatch")
async def run_dispatch_now(admin: SuperAdmin, db: DB):
    return await dispatch_due(db)
