from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # App
    APP_NAME: str = "Court Life - Court Management System"
    ENVIRONMENT: str = "development"
    API_V1_PREFIX: str = "/api/v1"
    CORS_ORIGINS: list[str] = ["http://localhost:3000"]

    # Database / cache
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/cms_dev"
    REDIS_URL: str = "redis://localhost:6379/0"

    # Auth
    JWT_SECRET: str = "change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    BCRYPT_ROUNDS: int = 12
    ACCESS_TOKEN_MINUTES: int = 60
    REFRESH_TOKEN_DAYS: int = 14
    OTP_TTL_MINUTES: int = 10
    OTP_MAX_ATTEMPTS: int = 5

    # Court data provider: "mock" | "ecourtsindia"
    COURT_PROVIDER: str = "mock"
    ECOURTSINDIA_BASE_URL: str = "https://webapi.ecourtsindia.com"
    ECOURTSINDIA_API_KEY: str = ""
    COURT_PROVIDER_TIMEOUT_SECONDS: float = 20.0

    # Indicative Enterprise rate card (INR per request) - PRD section 5
    RATE_CASE_SEARCH: float = 0.20
    RATE_CASE_DETAIL: float = 0.50
    RATE_CASE_REFRESH: float = 0.05
    RATE_ORDER_PDF: float = 1.25
    RATE_CALL_MINUTE: float = 1.00

    # Sync behaviour
    SYNC_NOW_COOLDOWN_MINUTES: int = 15
    SYNC_BATCH_SIZE: int = 100
    # eCourtsIndia refresh is asynchronous: request it, then read detail after this delay
    SYNC_REFRESH_SETTLE_MINUTES: int = 10

    # Reminders
    TIMEZONE: str = "Asia/Kolkata"
    REMINDER_SEND_HOUR: int = 8  # local hour for "N days before" reminders
    CALL_WINDOW_START_HOUR: int = 9  # calls only between 09:00 and 21:00 local
    CALL_WINDOW_END_HOUR: int = 21
    AUTO_REMINDER_OFFSETS: list[int] = [3, 1, 0]

    # Voice: "mock" | "exotel"
    VOICE_PROVIDER: str = "mock"
    EXOTEL_SUBDOMAIN: str = "api.exotel.com"
    EXOTEL_ACCOUNT_SID: str = ""
    EXOTEL_API_KEY: str = ""
    EXOTEL_API_TOKEN: str = ""
    EXOTEL_CALLER_ID: str = ""
    EXOTEL_FLOW_URL: str = ""  # Exotel app/flow that plays the reminder
    CALL_MAX_ATTEMPTS: int = 3
    CALL_RETRY_MINUTES: int = 10

    # SMS: "mock" | "exotel"
    SMS_PROVIDER: str = "mock"
    SMS_SENDER_ID: str = ""
    SMS_DLT_ENTITY_ID: str = ""

    # Email: "mock" | "smtp"
    EMAIL_PROVIDER: str = "mock"
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    EMAIL_FROM: str = "no-reply@courtlife.local"

    # Storage: "local" | "s3"
    STORAGE_BACKEND: str = "local"
    LOCAL_STORAGE_DIR: str = "./storage"
    S3_BUCKET: str = ""
    S3_REGION: str = "ap-south-1"
    MAX_UPLOAD_MB: int = 25

    # Webhooks
    WEBHOOK_SECRET: str = "change-me-webhook-secret"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
