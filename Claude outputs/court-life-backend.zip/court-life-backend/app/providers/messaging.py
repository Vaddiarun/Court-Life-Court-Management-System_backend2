"""Outbound channels: voice calls, SMS and email. Each has a mock (dev/test) and a real adapter."""

import asyncio
import smtplib
from abc import ABC, abstractmethod
from dataclasses import dataclass
from email.message import EmailMessage

import httpx

from app.core.config import settings


class ChannelError(Exception):
    pass


@dataclass
class CallResult:
    call_id: str
    status: str  # queued | failed


# ---------------------------------------------------------------- voice
class VoiceProvider(ABC):
    name = "base"

    @abstractmethod
    async def place_call(self, to_phone: str, message: str, language: str, reference: str) -> CallResult: ...


class MockVoiceProvider(VoiceProvider):
    name = "mock"
    sent: list[dict] = []
    fail_numbers: set[str] = set()

    async def place_call(self, to_phone, message, language, reference):
        if to_phone in self.fail_numbers:
            raise ChannelError("simulated call failure")
        call_id = f"mockcall-{len(self.sent) + 1}"
        self.sent.append({"to": to_phone, "message": message, "language": language, "ref": reference, "id": call_id})
        return CallResult(call_id, "queued")


class ExotelVoiceProvider(VoiceProvider):
    """Exotel Calls/connect: connects the number to an Exotel flow (app) that plays the reminder.

    The reminder text and language are passed in CustomField; the flow should use a
    'Greeting' applet with dynamic TTS or pick a prerecorded audio per language.
    Call status arrives at /api/v1/webhooks/exotel/call-status.
    """

    name = "exotel"

    async def place_call(self, to_phone, message, language, reference):
        url = (
            f"https://{settings.EXOTEL_API_KEY}:{settings.EXOTEL_API_TOKEN}@{settings.EXOTEL_SUBDOMAIN}"
            f"/v1/Accounts/{settings.EXOTEL_ACCOUNT_SID}/Calls/connect.json"
        )
        data = {
            "From": to_phone,
            "CallerId": settings.EXOTEL_CALLER_ID,
            "Url": settings.EXOTEL_FLOW_URL,
            "CallType": "trans",
            "CustomField": f"{reference}|{language}|{message}"[:1000],
            "StatusCallback": f"{settings.CORS_ORIGINS[0]}/api/v1/webhooks/exotel/call-status?token={settings.WEBHOOK_SECRET}",
        }
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(url, data=data)
        if resp.status_code >= 400:
            raise ChannelError(f"Exotel {resp.status_code}: {resp.text[:200]}")
        sid = resp.json().get("Call", {}).get("Sid", "")
        return CallResult(sid, "queued")


# ---------------------------------------------------------------- sms
class SmsProvider(ABC):
    name = "base"

    @abstractmethod
    async def send(self, to_phone: str, body: str, dlt_template_id: str | None = None) -> str: ...


class MockSmsProvider(SmsProvider):
    name = "mock"
    sent: list[dict] = []

    async def send(self, to_phone, body, dlt_template_id=None):
        self.sent.append({"to": to_phone, "body": body})
        return f"mocksms-{len(self.sent)}"


class ExotelSmsProvider(SmsProvider):
    """Indian SMS requires TRAI DLT registration: entity id + approved template id."""

    name = "exotel"

    async def send(self, to_phone, body, dlt_template_id=None):
        url = (
            f"https://{settings.EXOTEL_API_KEY}:{settings.EXOTEL_API_TOKEN}@{settings.EXOTEL_SUBDOMAIN}"
            f"/v1/Accounts/{settings.EXOTEL_ACCOUNT_SID}/Sms/send.json"
        )
        data = {"From": settings.SMS_SENDER_ID, "To": to_phone, "Body": body, "DltEntityId": settings.SMS_DLT_ENTITY_ID}
        if dlt_template_id:
            data["DltTemplateId"] = dlt_template_id
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(url, data=data)
        if resp.status_code >= 400:
            raise ChannelError(f"Exotel SMS {resp.status_code}: {resp.text[:200]}")
        return resp.json().get("SMSMessage", {}).get("Sid", "")


# ---------------------------------------------------------------- email
class EmailProvider(ABC):
    name = "base"

    @abstractmethod
    async def send(self, to: str, subject: str, body: str) -> str: ...


class MockEmailProvider(EmailProvider):
    name = "mock"
    sent: list[dict] = []

    async def send(self, to, subject, body):
        self.sent.append({"to": to, "subject": subject, "body": body})
        return f"mockmail-{len(self.sent)}"


class SmtpEmailProvider(EmailProvider):
    name = "smtp"

    async def send(self, to, subject, body):
        msg = EmailMessage()
        msg["From"], msg["To"], msg["Subject"] = settings.EMAIL_FROM, to, subject
        msg.set_content(body)

        def _send():
            with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=20) as s:
                s.starttls()
                if settings.SMTP_USER:
                    s.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
                s.send_message(msg)

        try:
            await asyncio.to_thread(_send)
        except (smtplib.SMTPException, OSError) as e:
            raise ChannelError(str(e)) from e
        return "smtp"


def get_voice() -> VoiceProvider:
    return ExotelVoiceProvider() if settings.VOICE_PROVIDER == "exotel" else MockVoiceProvider()


def get_sms() -> SmsProvider:
    return ExotelSmsProvider() if settings.SMS_PROVIDER == "exotel" else MockSmsProvider()


def get_email() -> EmailProvider:
    return SmtpEmailProvider() if settings.EMAIL_PROVIDER == "smtp" else MockEmailProvider()


def reset_mocks() -> None:
    MockVoiceProvider.sent = []
    MockVoiceProvider.fail_numbers = set()
    MockSmsProvider.sent = []
    MockEmailProvider.sent = []
