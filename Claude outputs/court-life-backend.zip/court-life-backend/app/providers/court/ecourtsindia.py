"""eCourtsIndia partner API adapter (https://webapi.ecourtsindia.com, Bearer auth).

Documented endpoints used:
  GET  /api/partner/case/{cnr}          full case record (parties, advocates, judges, hearings, IAs, orders)
  POST /api/partner/case/{cnr}/refresh  async re-scrape; poll detail until dateModified advances
  GET  /api/partner/search              CourtCodes, CaseTypes, FilingYears, Query, Litigants, Page, PageSize

The public docs do not publish the full response schema, so `_parse_case` reads fields
defensively with several candidate keys. VERIFY the mapping against a live response
during the PRD proof-of-concept and tighten it (see tests/test_ecourtsindia_adapter.py).
"""

from datetime import date, datetime
from typing import Any

import httpx
from tenacity import AsyncRetrying, retry_if_exception_type, stop_after_attempt, wait_exponential

from app.core.config import settings
from app.providers.court.base import (
    CaseNotFound,
    CaseRecord,
    CourtDataProvider,
    HearingRecord,
    OrderRecord,
    ProviderAuthError,
    ProviderError,
    ProviderRateLimited,
)


def _pick(d: dict, *keys: str, default: Any = None) -> Any:
    for k in keys:
        cur: Any = d
        for part in k.split("."):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                cur = None
                break
        if cur not in (None, "", []):
            return cur
    return default


def _date(v: Any) -> date | None:
    if not v:
        return None
    if isinstance(v, date):
        return v
    s = str(v).strip()
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d", "%d %B %Y", "%d %b %Y"):
        try:
            return datetime.strptime(s[:10] if fmt.startswith("%Y-") else s, fmt).date()
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).date()
    except ValueError:
        return None


def _names(v: Any) -> list[str]:
    if not v:
        return []
    if isinstance(v, str):
        return [v]
    out = []
    for item in v:
        if isinstance(item, str):
            out.append(item)
        elif isinstance(item, dict):
            n = _pick(item, "name", "partyName", "advocateName", "judgeName")
            if n:
                out.append(str(n))
    return out


def _parse_case(cnr: str, payload: dict) -> CaseRecord:
    data = payload.get("data", payload) if isinstance(payload, dict) else {}
    if isinstance(data, dict) and isinstance(data.get("case"), dict):
        data = {**data, **data["case"]}

    parties = _pick(data, "parties", default={})
    petitioners = _names(_pick(data, "petitioners", "petitioner") or (parties.get("petitioners") if isinstance(parties, dict) else None))
    respondents = _names(_pick(data, "respondents", "respondent") or (parties.get("respondents") if isinstance(parties, dict) else None))

    hearings = []
    for h in _pick(data, "hearings", "hearingHistory", "history", default=[]) or []:
        if not isinstance(h, dict):
            continue
        hd = _date(_pick(h, "hearingDate", "date", "businessOnDate"))
        if hd:
            hearings.append(
                HearingRecord(hd, _pick(h, "purpose", "purposeOfHearing", "stage"), _pick(h, "judge", "judgeName"), _pick(h, "business"))
            )

    orders = []
    order_items = _pick(data, "orders", default=None) or _pick(data, "files.files", default=[]) or []
    for o in order_items:
        if isinstance(o, dict):
            orders.append(
                OrderRecord(_date(_pick(o, "orderDate", "date")), _pick(o, "title", "orderType", "fileName"), _pick(o, "url", "pdfUrl"))
            )

    status = _pick(data, "caseStatus", "status")
    disposed = bool(_pick(data, "isDisposed", default=False)) or (str(status or "").lower().startswith("dispos"))
    pet, res = (petitioners[0] if petitioners else None), (respondents[0] if respondents else None)
    title = _pick(data, "title", "caseTitle") or (f"{pet} vs {res}" if pet and res else cnr)

    return CaseRecord(
        cnr=cnr,
        title=str(title),
        case_number=_pick(data, "caseNumber", "registrationNumber", "filingNumber"),
        case_type=_pick(data, "caseType", "caseTypeName"),
        case_year=_pick(data, "caseYear", "filingYear", "registrationYear"),
        court_name=_pick(data, "courtName", "court.name", "establishmentName"),
        court_level=_pick(data, "courtLevel", "courtType"),
        state=_pick(data, "state", "stateName", "court.state"),
        district=_pick(data, "district", "districtName", "court.district"),
        judge=(_names(_pick(data, "judges", default=[])) or [None])[0] or _pick(data, "judge", "courtNumberAndJudge"),
        petitioners=petitioners,
        respondents=respondents,
        advocates=_names(_pick(data, "advocates", default=[])),
        filing_date=_date(_pick(data, "filingDate", "dateOfFiling")),
        registration_date=_date(_pick(data, "registrationDate", "dateOfRegistration")),
        status=status,
        stage=_pick(data, "stage", "caseStage", "stageOfCase"),
        next_hearing_date=_date(_pick(data, "nextHearingDate", "nextDate", "next_hearing_date")),
        is_disposed=disposed,
        hearings=hearings,
        orders=orders,
        provider_modified_at=_pick(data, "dateModified", "lastModified", "updatedAt"),
        raw=payload if isinstance(payload, dict) else {},
    )


class ECourtsIndiaProvider(CourtDataProvider):
    name = "ecourtsindia"

    def __init__(self, client: httpx.AsyncClient | None = None):
        if not settings.ECOURTSINDIA_API_KEY and client is None:
            raise ProviderAuthError("ECOURTSINDIA_API_KEY is not configured")
        self._client = client or httpx.AsyncClient(
            base_url=settings.ECOURTSINDIA_BASE_URL,
            headers={"Authorization": f"Bearer {settings.ECOURTSINDIA_API_KEY}", "Accept": "application/json"},
            timeout=settings.COURT_PROVIDER_TIMEOUT_SECONDS,
        )

    async def _request(self, method: str, url: str, **kw) -> httpx.Response:
        async for attempt in AsyncRetrying(
            stop=stop_after_attempt(3),
            wait=wait_exponential(multiplier=0.5, max=8),
            retry=retry_if_exception_type((httpx.TransportError, ProviderRateLimited)),
            reraise=True,
        ):
            with attempt:
                resp = await self._client.request(method, url, **kw)
                if resp.status_code == 429:
                    raise ProviderRateLimited("rate limited")
        if resp.status_code in (401, 403):
            raise ProviderAuthError(f"auth failed ({resp.status_code})")
        if resp.status_code == 404:
            raise CaseNotFound(url)
        if resp.status_code >= 400:
            raise ProviderError(f"{resp.status_code}: {resp.text[:300]}")
        return resp

    async def get_case(self, cnr: str) -> CaseRecord:
        resp = await self._request("GET", f"/api/partner/case/{cnr}")
        return _parse_case(cnr, resp.json())

    async def request_refresh(self, cnr: str) -> None:
        await self._request("POST", f"/api/partner/case/{cnr}/refresh")

    async def search(self, **filters) -> list[dict]:
        params = {
            "Query": filters.get("query"),
            "CourtCodes": filters.get("court_code"),
            "CaseTypes": filters.get("case_type"),
            "FilingYears": filters.get("year"),
            "Litigants": filters.get("litigant"),
            "Page": filters.get("page", 1),
            "PageSize": min(int(filters.get("page_size", 20)), 100),
        }
        resp = await self._request("GET", "/api/partner/search", params={k: v for k, v in params.items() if v})
        body = resp.json()
        items = _pick(body, "data.results", "data.items", "results", "items", "data", default=[]) or []
        return [
            {
                "cnr": _pick(i, "cnr", "cnrNumber"),
                "title": _pick(i, "title", "caseTitle"),
                "court_name": _pick(i, "courtName"),
                "case_number": _pick(i, "caseNumber"),
            }
            for i in items
            if isinstance(i, dict)
        ]
